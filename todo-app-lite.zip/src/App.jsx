import "./App.css";
import { useState } from "react";

const App = () => {
  const [todoList, setTodoList] = useState([]);

  const handleSubmit = (event) => {
    event.preventDefault();
    const inputField = document.getElementById("addTodoField");
    notifyTodoAdded({
      id: Math.random() * 1000,
      title: inputField.value,
      complete: false,
    });
    inputField.value = "";
  };

  const notifyTodoAdded = (newTodo) => {
    setTodoList([...todoList, newTodo]);
  };
  const notifyTodoComplete = (id) => {
    setTodoList(todoList.map((item) => (item.id === Number(id) ? { ...item, complete: !item.complete } : item)));
  };
  const notifyTodoDeleted = (id) => {
    setTodoList(todoList.filter((item) => item.id !== Number(id)));
  };

  return (
    <div className="App">
      <h1>Todo App Lite</h1>
      <form onSubmit={handleSubmit}>
        <input type="text" id="addTodoField" />
      </form>
      <ul>
        {todoList.map((item) => {
          return (
            <li key={item.id} className="TodoItem">
              <article>
                <input
                  type="checkbox"
                  onChange={() => {
                    notifyTodoComplete(item.id);
                  }}
                />
                <h3
                  style={{
                    textDecoration: item.complete ? "line-through" : "none" /* If item is completed -> Dash the text */,
                  }}
                >
                  {item.title}
                </h3>
              </article>
              <button onClick={() => notifyTodoDeleted(item.id)}>delete</button>
            </li>
          );
        })}
      </ul>
    </div>
  );
};

export default App;
